"""Run from the backend folder:  python -m unittest discover -s tests -v   (no extra packages needed)"""
import os
import tempfile
import unittest

os.environ["DESK_DB"] = os.path.join(tempfile.mkdtemp(), "test.db")

from app import auth, services                      # noqa: E402
from app.agent.knowledge_base import get_kb         # noqa: E402
from app.agent.orchestrator import run_pipeline     # noqa: E402
from app.agent.policy import decide                 # noqa: E402
from app.database import init_db                    # noqa: E402
from app.seed import seed_if_empty                  # noqa: E402


def login(email, pw):
    return auth.user_for_token(auth.login(email, pw)[0])


class DeskTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        init_db()
        seed_if_empty(count=20)
        cls.emp = login("employee@demo.com", "demo123")
        cls.admin = login("admin@demo.com", "admin123")

    def run_ticket(self, title, desc, cat=None):
        tid = services.create_ticket(self.emp, title, desc, cat)
        run_pipeline(tid, delay=0)
        return services.get_ticket(tid, self.emp)

    def test_rag_finds_relevant_article(self):
        hits = get_kb().search("outlook stuck on updating no new email", 3)
        self.assertEqual(hits[0]["article"]["id"], "KB-008")

    def test_guided_troubleshooting(self):
        t = self.run_ticket("Wi-Fi connected but no internet", "Laptop is connected to office wifi but websites will not load")
        self.assertEqual((t["status"], t["category"]), ("Troubleshooting", "Wi-Fi"))
        self.assertGreaterEqual(len(t["steps"]), 4)

    def test_auto_resolution_for_account_lockout(self):
        t = self.run_ticket("Account locked out", "I typed my password wrong too many times and my account is locked")
        self.assertEqual((t["status"], t["resolved_by"]), ("Resolved", "AI"))

    def test_security_ticket_is_escalated_not_auto_fixed(self):
        t = self.run_ticket("Clicked phishing link", "I clicked a phishing link and I think I am hacked")
        self.assertEqual(t["status"], "Escalated")
        self.assertTrue(t["security_flag"])
        self.assertIsNotNone(t["assignee"])

    def test_unknown_issue_escalates_on_low_confidence(self):
        t = self.run_ticket("Need a standing desk", "Please order a standing desk for my workstation")
        self.assertEqual(t["status"], "Escalated")

    def test_user_feedback_escalates_and_it_resolves(self):
        t = self.run_ticket("Computer is very slow", "It freezes all the time and takes ages to start up")
        services.submit_feedback(t["id"], self.emp, False, "still slow")
        self.assertEqual(services.get_ticket(t["id"], self.emp)["status"], "Escalated")
        services.admin_update(t["id"], self.admin, status="Resolved", note="Replaced failing disk")
        self.assertEqual(services.get_ticket(t["id"], self.admin)["status"], "Resolved")

    def test_access_control(self):
        t = self.run_ticket("Printer offline", "The shared printer shows offline and nothing prints")
        other = login("rohan@demo.com", "demo123")
        with self.assertRaises(services.Forbidden):
            services.get_ticket(t["id"], other)

    def test_policy_never_auto_acts_on_critical(self):
        d = {"confidence": 0.9, "article": {"auto_action": "unlock_account", "auto_resolves": True, "risk": "low"}}
        self.assertEqual(decide({"severity": "Critical", "security_flag": 0}, d)["action"], "escalate")

    def test_analytics_and_filters(self):
        a = services.analytics()
        self.assertGreater(a["kpis"]["total"], 20)
        self.assertTrue(services.list_tickets(self.admin, category="Printer") is not None)


if __name__ == "__main__":
    unittest.main()
