"""HTTP layer (FastAPI). Thin: validate input, call services/agent, translate errors."""
from fastapi import APIRouter, BackgroundTasks, Depends, Header, HTTPException, Query
from pydantic import BaseModel

from . import auth, services
from .agent.knowledge_base import get_kb
from .agent.llm import get_llm
from .agent.orchestrator import run_pipeline

router = APIRouter(prefix="/api")


def current_user(authorization: str = Header(default="")) -> dict:
    token = authorization.removeprefix("Bearer ").strip()
    user = auth.user_for_token(token)
    if not user:
        raise HTTPException(401, "Please sign in.")
    user["token"] = token
    return user


def admin_only(user: dict = Depends(current_user)) -> dict:
    if user["role"] != "admin":
        raise HTTPException(403, "IT staff only.")
    return user


def guarded(fn, *args, **kwargs):
    """Translate service-layer exceptions into HTTP errors."""
    try:
        return fn(*args, **kwargs)
    except services.NotFound as e:
        raise HTTPException(404, str(e))
    except services.Forbidden as e:
        raise HTTPException(403, str(e))
    except services.BadRequest as e:
        raise HTTPException(400, str(e))


class LoginBody(BaseModel):
    email: str
    password: str


class TicketBody(BaseModel):
    title: str
    description: str
    category: str | None = None


class StepBody(BaseModel):
    done: bool


class FeedbackBody(BaseModel):
    resolved: bool
    note: str | None = None


class AdminUpdateBody(BaseModel):
    status: str | None = None
    assigned_to: int | None = None
    note: str | None = None
    resolution: str | None = None


# ---- auth & meta ----
@router.post("/auth/login")
def login(body: LoginBody):
    result = auth.login(body.email, body.password)
    if not result:
        raise HTTPException(401, "Incorrect email or password.")
    token, user = result
    return {"token": token, "user": user}


@router.get("/auth/me")
def me(user: dict = Depends(current_user)):
    return {k: v for k, v in user.items() if k != "token"}


@router.post("/auth/logout")
def logout(user: dict = Depends(current_user)):
    auth.logout(user["token"])
    return {"ok": True}


@router.get("/meta")
def meta(user: dict = Depends(current_user)):
    return {"categories": services.CATEGORIES, "statuses": services.STATUSES,
            "priorities": services.PRIORITIES, "severities": services.SEVERITIES,
            "ai_engine": get_llm().name}


# ---- tickets ----
@router.post("/tickets", status_code=201)
def create_ticket(body: TicketBody, background: BackgroundTasks, user: dict = Depends(current_user)):
    tid = guarded(services.create_ticket, user, body.title, body.description, body.category)
    background.add_task(run_pipeline, tid)  # the agent works asynchronously; the UI polls for progress
    return guarded(services.get_ticket, tid, user)


@router.get("/tickets")
def list_tickets(q: str | None = None, status: str | None = None, category: str | None = None,
                 priority: str | None = None, severity: str | None = None, mine: bool = False,
                 sort: str = "newest", user: dict = Depends(current_user)):
    return services.list_tickets(user, q, status, category, priority, severity, mine, sort)


@router.get("/tickets/{ticket_id}")
def get_ticket(ticket_id: int, user: dict = Depends(current_user)):
    return guarded(services.get_ticket, ticket_id, user)


@router.post("/tickets/{ticket_id}/steps/{step_id}")
def toggle_step(ticket_id: int, step_id: int, body: StepBody, user: dict = Depends(current_user)):
    guarded(services.toggle_step, ticket_id, step_id, body.done, user)
    return guarded(services.get_ticket, ticket_id, user)


@router.post("/tickets/{ticket_id}/feedback")
def feedback(ticket_id: int, body: FeedbackBody, user: dict = Depends(current_user)):
    guarded(services.submit_feedback, ticket_id, user, body.resolved, body.note)
    return guarded(services.get_ticket, ticket_id, user)


# ---- IT admin ----
@router.patch("/admin/tickets/{ticket_id}")
def admin_update(ticket_id: int, body: AdminUpdateBody, user: dict = Depends(admin_only)):
    guarded(services.admin_update, ticket_id, user, body.status, body.assigned_to, body.note, body.resolution)
    return guarded(services.get_ticket, ticket_id, user)


@router.get("/admin/analytics")
def analytics(user: dict = Depends(admin_only)):
    return services.analytics()


@router.get("/admin/engineers")
def engineers(user: dict = Depends(admin_only)):
    return services.list_engineers()


# ---- knowledge base ----
@router.get("/kb")
def kb_list(user: dict = Depends(current_user)):
    return get_kb().articles


@router.get("/kb/search")
def kb_search(q: str = Query(min_length=2), user: dict = Depends(current_user)):
    return [{"score": h["score"], "article": h["article"]} for h in get_kb().search(q, k=5)]
