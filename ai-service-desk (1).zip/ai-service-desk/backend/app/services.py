"""Business logic. The HTTP layer (api.py) only validates input and calls these functions."""
from collections import Counter
from datetime import datetime, timedelta, timezone

from .agent import orchestrator as agent
from .database import db, loads, now_iso

CATEGORIES = ["Network", "Wi-Fi", "Software", "Hardware", "Email", "Password/Login", "Printer", "System Performance"]
STATUSES = ["Open", "AI Investigating", "Troubleshooting", "Resolved", "Escalated"]
PRIORITIES = ["Low", "Medium", "High", "Urgent"]
SEVERITIES = ["Minor", "Moderate", "Major", "Critical"]


class NotFound(Exception): ...
class Forbidden(Exception): ...
class BadRequest(Exception): ...


def _parse(ts):
    return datetime.fromisoformat(ts.replace("Z", "+00:00"))


# ---------- tickets ----------
def create_ticket(user: dict, title: str, description: str, category: str | None) -> int:
    title, description = title.strip(), description.strip()
    if len(title) < 5:
        raise BadRequest("Please enter a short title (at least 5 characters).")
    if len(description) < 15:
        raise BadRequest("Please describe the problem in a bit more detail (at least 15 characters).")
    if category and category not in CATEGORIES:
        raise BadRequest("Unknown category.")
    ts = now_iso()
    with db() as conn:
        cur = conn.execute(
            "INSERT INTO tickets(user_id, title, description, user_category, status, created_at, updated_at) VALUES (?,?,?,?,?,?,?)",
            (user["id"], title, description, category, "Open", ts, ts))
        tid = cur.lastrowid
        conn.execute("UPDATE tickets SET ticket_no = ? WHERE id = ?", (f"TCK-{1000 + tid}", tid))
        agent.add_event(conn, tid, "created", f"Ticket created by {user['name']}.", "employee")
    return tid


SUMMARY_SQL = """
SELECT t.id, t.ticket_no, t.title, t.category, t.user_category, t.priority, t.severity, t.status, t.confidence,
       t.resolved_by, t.created_at, t.updated_at, t.resolved_at, t.security_flag,
       u.name AS requester, u.department AS department, a.name AS assignee
FROM tickets t JOIN users u ON u.id = t.user_id LEFT JOIN users a ON a.id = t.assigned_to
"""


def list_tickets(viewer: dict, q=None, status=None, category=None, priority=None, severity=None,
                 mine=False, sort="newest", limit=200):
    where, params = [], []
    if viewer["role"] != "admin" or mine:
        where.append("t.user_id = ?"); params.append(viewer["id"])
    if status:
        where.append("t.status = ?"); params.append(status)
    if category:
        where.append("COALESCE(t.category, t.user_category) = ?"); params.append(category)
    if priority:
        where.append("t.priority = ?"); params.append(priority)
    if severity:
        where.append("t.severity = ?"); params.append(severity)
    if q:
        like = f"%{q.strip()}%"
        where.append("(t.title LIKE ? OR t.description LIKE ? OR t.ticket_no LIKE ? OR u.name LIKE ? OR t.diagnosis LIKE ?)")
        params += [like] * 5
    order = {"oldest": "t.created_at ASC", "priority": "CASE t.priority WHEN 'Urgent' THEN 0 WHEN 'High' THEN 1 WHEN 'Medium' THEN 2 ELSE 3 END, t.created_at DESC"}.get(sort, "t.created_at DESC")
    sql = SUMMARY_SQL + (" WHERE " + " AND ".join(where) if where else "") + f" ORDER BY {order} LIMIT ?"
    with db() as conn:
        rows = [dict(r) for r in conn.execute(sql, (*params, limit))]
    for r in rows:
        r["category"] = r["category"] or r["user_category"] or "Pending triage"
    return rows


def _load_ticket(conn, ticket_id: int, viewer: dict) -> dict:
    row = conn.execute(SUMMARY_SQL + " WHERE t.id = ?", (ticket_id,)).fetchone()
    if not row:
        raise NotFound("Ticket not found.")
    t = dict(row)
    owner = conn.execute("SELECT user_id FROM tickets WHERE id = ?", (ticket_id,)).fetchone()["user_id"]
    if viewer["role"] != "admin" and owner != viewer["id"]:
        raise Forbidden("You can only view your own tickets.")
    return t


def get_ticket(ticket_id: int, viewer: dict) -> dict:
    with db() as conn:
        t = _load_ticket(conn, ticket_id, viewer)
        full = dict(conn.execute("SELECT description, diagnosis, kb_sources, auto_action, resolution_summary, escalation_reason, escalated_at, user_category FROM tickets WHERE id = ?", (ticket_id,)).fetchone())
        t.update(full)
        t["kb_sources"] = loads(full["kb_sources"], [])
        t["category"] = t["category"] or t["user_category"] or "Pending triage"
        t["steps"] = [dict(r) for r in conn.execute("SELECT id, position, text, done FROM steps WHERE ticket_id = ? ORDER BY position", (ticket_id,))]
        t["events"] = [dict(r) for r in conn.execute("SELECT stage, message, actor, created_at FROM events WHERE ticket_id = ? ORDER BY id", (ticket_id,))]
    return t


def toggle_step(ticket_id: int, step_id: int, done: bool, viewer: dict) -> None:
    with db() as conn:
        t = _load_ticket(conn, ticket_id, viewer)
        if t["status"] not in ("Troubleshooting", "Escalated"):
            raise BadRequest("Steps can only be changed while a ticket is being troubleshot.")
        step = conn.execute("SELECT * FROM steps WHERE id = ? AND ticket_id = ?", (step_id, ticket_id)).fetchone()
        if not step:
            raise NotFound("Step not found.")
        conn.execute("UPDATE steps SET done = ? WHERE id = ?", (1 if done else 0, step_id))
        agent.set_fields(conn, ticket_id)
        if done:
            agent.add_event(conn, ticket_id, "step", f"Employee completed step {step['position']}: {step['text']}", "employee")


def submit_feedback(ticket_id: int, viewer: dict, resolved: bool, note: str | None) -> None:
    with db() as conn:
        t = _load_ticket(conn, ticket_id, viewer)
        if t["status"] not in ("Troubleshooting", "Resolved"):
            raise BadRequest("Feedback is only available for tickets in troubleshooting or resolved state.")
        note = (note or "").strip()
        if resolved:
            if t["status"] == "Resolved":
                raise BadRequest("This ticket is already resolved.")
            agent.add_event(conn, ticket_id, "feedback", "Employee confirmed the issue is fixed." + (f" Note: {note}" if note else ""), "employee")
            agent.resolve(conn, ticket_id, "Employee", actor="employee")
        else:
            agent.add_event(conn, ticket_id, "feedback", "Employee reported the issue is NOT fixed." + (f" Note: {note}" if note else ""), "employee")
            reason = "The employee reported the issue is still not resolved after the agent's help." + (f" Employee note: {note}" if note else "")
            agent.escalate(conn, ticket_id, reason, "system")


def admin_update(ticket_id: int, admin: dict, status=None, assigned_to=None, note=None, resolution=None) -> None:
    if admin["role"] != "admin":
        raise Forbidden("IT staff only.")
    with db() as conn:
        _load_ticket(conn, ticket_id, admin)
        if assigned_to:
            eng = conn.execute("SELECT id, name FROM users WHERE id = ? AND role = 'admin'", (assigned_to,)).fetchone()
            if not eng:
                raise BadRequest("Assignee must be an IT engineer.")
            agent.set_fields(conn, ticket_id, assigned_to=eng["id"])
            agent.add_event(conn, ticket_id, "assignment", f"Assigned to {eng['name']}.", "it")
        if note and note.strip():
            agent.add_event(conn, ticket_id, "note", note.strip(), "it")
        if status:
            if status not in STATUSES:
                raise BadRequest("Unknown status.")
            if status == "Resolved":
                agent.resolve(conn, ticket_id, "IT", (resolution or note or "").strip() or None, actor="it")
            elif status == "Escalated":
                agent.escalate(conn, ticket_id, f"Escalated manually by {admin['name']}.", "it")
            else:
                agent.set_fields(conn, ticket_id, status=status, resolved_at=None, resolved_by=None)
                agent.add_event(conn, ticket_id, "status", f"Status changed to {status}.", "it")


def list_engineers():
    with db() as conn:
        return [dict(r) for r in conn.execute("SELECT id, name FROM users WHERE role = 'admin' ORDER BY name")]


# ---------- analytics ----------
def analytics() -> dict:
    with db() as conn:
        rows = [dict(r) for r in conn.execute("SELECT * FROM tickets")]
    total = len(rows)
    resolved = [r for r in rows if r["status"] == "Resolved"]
    auto = [r for r in resolved if r["resolved_by"] in ("AI", "Employee")]
    human = [r for r in resolved if r["resolved_by"] == "IT"]
    ever_escalated = [r for r in rows if r["escalated_at"]]

    def avg_minutes(items):
        vals = [(_parse(r["resolved_at"]) - _parse(r["created_at"])).total_seconds() / 60 for r in items if r["resolved_at"]]
        return round(sum(vals) / len(vals), 1) if vals else None

    today = datetime.now(timezone.utc).date()
    days = [today - timedelta(days=i) for i in range(13, -1, -1)]
    created_per_day = Counter(_parse(r["created_at"]).date() for r in rows)
    resolved_per_day = Counter(_parse(r["resolved_at"]).date() for r in resolved if r["resolved_at"])

    def count_by(key, order):
        c = Counter((r[key] if key != "category" else (r["category"] or r["user_category"] or "Pending triage")) or "Pending" for r in rows)
        return [{"label": k, "count": c.get(k, 0)} for k in order if c.get(k, 0)] + \
               [{"label": k, "count": v} for k, v in c.items() if k not in order]

    kb_counter, kb_titles = Counter(), {}
    for r in rows:
        src = loads(r["kb_sources"], [])
        if src:
            kb_counter[src[0]["id"]] += 1
            kb_titles[src[0]["id"]] = src[0]["title"]
    confs = [r["confidence"] for r in rows if r["confidence"] is not None]

    return {
        "kpis": {
            "total": total,
            "active": sum(1 for r in rows if r["status"] != "Resolved"),
            "escalated_now": sum(1 for r in rows if r["status"] == "Escalated"),
            "resolved": len(resolved),
            "ai_resolution_rate": round(100 * len(auto) / total) if total else 0,
            "escalation_rate": round(100 * len(ever_escalated) / total) if total else 0,
            "avg_minutes_ai": avg_minutes(auto),
            "avg_minutes_human": avg_minutes(human),
            "avg_confidence": round(100 * sum(confs) / len(confs)) if confs else 0,
        },
        "by_status": count_by("status", STATUSES),
        "by_category": count_by("category", CATEGORIES),
        "by_priority": count_by("priority", PRIORITIES),
        "daily": [{"date": d.isoformat(), "created": created_per_day.get(d, 0), "resolved": resolved_per_day.get(d, 0)} for d in days],
        "top_articles": [{"id": k, "title": kb_titles[k], "count": v} for k, v in kb_counter.most_common(5)],
    }
