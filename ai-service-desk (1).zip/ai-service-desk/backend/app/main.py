"""Application entry point.  Run from the backend folder:  uvicorn app.main:app --reload"""
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from .api import router
from .config import FRONTEND_DIR
from .database import init_db
from .seed import seed_if_empty


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    seed_if_empty()
    yield


app = FastAPI(title="AI IT Service Desk Autonomous Resolution Agent", version="1.0.0", lifespan=lifespan)
app.include_router(router)
# The frontend is plain HTML/CSS/JS, so no build step is needed. Mounted last so /api/* wins.
app.mount("/", StaticFiles(directory=FRONTEND_DIR, html=True), name="frontend")
