"""The autonomous agent pipeline.

Ticket created -> triage -> knowledge base (RAG) search -> diagnosis -> policy decision ->
(automated fix | guided troubleshooting | human escalation).

Every stage commits to the database and writes a timeline event, so the UI can show the agent
working in real time by polling the ticket.
"""
import json
import time
import traceback

from ..config import STEP_DELAY
from ..database import db, now_iso
from . import tools
from .knowledge_base import get_kb
from .llm import get_llm
from .policy import decide

SECURITY_STEPS = [
    "Disconnect the device from Wi-Fi and unplug the network cable.",
    "Do not enter passwords, click further links or delete anything.",
    "Leave the device powered on and wait for the IT Security team to contact you.",
]


# ---------- small DB helpers (shared with services.py) ----------
def add_event(conn, ticket_id, stage, message, actor="ai"):
    conn.execute("INSERT INTO events(ticket_id, stage, message, actor, created_at) VALUES (?,?,?,?,?)",
                 (ticket_id, stage, message, actor, now_iso()))


def set_fields(conn, ticket_id, **fields):
    fields["updated_at"] = now_iso()
    cols = ", ".join(f"{k} = ?" for k in fields)
    conn.execute(f"UPDATE tickets SET {cols} WHERE id = ?", (*fields.values(), ticket_id))


def add_steps(conn, ticket_id, texts, done_first=0):
    for i, text in enumerate(texts):
        conn.execute("INSERT INTO steps(ticket_id, position, text, done) VALUES (?,?,?,?)",
                     (ticket_id, i + 1, text, 1 if i < done_first else 0))


def pick_engineer(conn):
    row = conn.execute(
        """SELECT u.id, COUNT(t.id) AS c FROM users u
           LEFT JOIN tickets t ON t.assigned_to = u.id AND t.status = 'Escalated'
           WHERE u.role = 'admin' GROUP BY u.id ORDER BY c, u.id LIMIT 1""").fetchone()
    return row["id"] if row else None


def escalate(conn, ticket_id, reason, actor="ai"):
    steps = conn.execute("SELECT done FROM steps WHERE ticket_id = ?", (ticket_id,)).fetchall()
    done = sum(s["done"] for s in steps)
    progress = (f" Self-service progress: {done} of {len(steps)} steps completed." if steps
                else " No self-service steps were attempted.")
    eng_id = pick_engineer(conn)
    eng = conn.execute("SELECT name FROM users WHERE id = ?", (eng_id,)).fetchone() if eng_id else None
    set_fields(conn, ticket_id, status="Escalated", escalation_reason=reason, escalated_at=now_iso(),
               assigned_to=eng_id, resolved_at=None, resolved_by=None, resolution_summary=None)
    add_event(conn, ticket_id, "escalation",
              f"Escalated to human IT support. {reason}{progress}" + (f" Assigned to {eng['name']}." if eng else ""), actor)


def build_resolution_summary(ticket, steps, how, note=None):
    done = sum(1 for s in steps if s["done"])
    lines = [f"Issue: {ticket['title']}."]
    if ticket.get("diagnosis"):
        lines.append(f"Diagnosis: {ticket['diagnosis']}")
    if how == "AI":
        lines.append(f"Resolution: The agent fixed this automatically. {note}")
    elif how == "Employee":
        lines.append(f"Resolution: The employee completed {done} of {len(steps)} guided steps and confirmed the issue is fixed.")
    else:
        lines.append(f"Resolution: Resolved by IT support. {note or 'No additional notes.'}")
    return "\n".join(lines)


def resolve(conn, ticket_id, how, note=None, actor="ai"):
    t = dict(conn.execute("SELECT * FROM tickets WHERE id = ?", (ticket_id,)).fetchone())
    steps = [dict(s) for s in conn.execute("SELECT * FROM steps WHERE ticket_id = ?", (ticket_id,))]
    summary = build_resolution_summary(t, steps, how, note)
    set_fields(conn, ticket_id, status="Resolved", resolution_summary=summary, resolved_by=how, resolved_at=now_iso())
    add_event(conn, ticket_id, "resolution", "Ticket resolved. " + summary.splitlines()[-1], actor)


# ---------- the pipeline ----------
def run_pipeline(ticket_id: int, delay: float | None = None) -> None:
    try:
        _run(ticket_id, STEP_DELAY if delay is None else delay)
    except Exception as exc:  # never leave a ticket stuck in "AI Investigating"
        traceback.print_exc()
        with db() as conn:
            escalate(conn, ticket_id, f"The AI agent hit an internal error ({type(exc).__name__}) and handed the ticket to a human.", "system")


def _run(ticket_id: int, delay: float) -> None:
    llm, kb = get_llm(), get_kb()
    with db() as conn:
        t = dict(conn.execute("SELECT * FROM tickets WHERE id = ?", (ticket_id,)).fetchone())
        user = dict(conn.execute("SELECT id, name, email FROM users WHERE id = ?", (t["user_id"],)).fetchone())

    # Stage 1: triage
    time.sleep(delay)
    with db() as conn:
        set_fields(conn, ticket_id, status="AI Investigating")
        add_event(conn, ticket_id, "triage", f"AI agent ({llm.name}) picked up the ticket and is reading the description.")
    time.sleep(delay)
    tri = llm.triage(t["title"], t["description"], t["user_category"])
    t.update(tri)
    with db() as conn:
        set_fields(conn, ticket_id, category=tri["category"], priority=tri["priority"], severity=tri["severity"],
                   security_flag=int(tri["security_flag"]))
        add_event(conn, ticket_id, "triage",
                  f"Classified as {tri['category']} with {tri['priority']} priority and {tri['severity']} severity. {tri['reason']}")

    # Stage 2: RAG search
    time.sleep(delay)
    hits = kb.search(f"{t['title']}. {t['description']}", k=3, category=tri["category"])
    sources = [{"id": h["article"]["id"], "title": h["article"]["title"], "category": h["article"]["category"],
                "score": h["score"]} for h in hits]
    with db() as conn:
        set_fields(conn, ticket_id, kb_sources=json.dumps(sources))
        msg = ("Searched the knowledge base and retrieved " + ", ".join(f"{s['id']} ({s['title']})" for s in sources) + "."
               if sources else "Searched the knowledge base but found no relevant articles.")
        add_event(conn, ticket_id, "kb_search", msg)

    # Stage 3: diagnosis
    time.sleep(delay)
    diag = llm.diagnose(t, hits)
    steps = diag["steps"]
    diagnosis_text = diag["diagnosis"]
    if t["security_flag"]:
        steps = SECURITY_STEPS
        diagnosis_text = "This ticket describes a possible security incident or data-loss situation. It is not suitable for self-service repair."
    t["diagnosis"] = diagnosis_text
    with db() as conn:
        set_fields(conn, ticket_id, diagnosis=diagnosis_text, confidence=diag["confidence"])
        add_event(conn, ticket_id, "diagnosis", f"{diagnosis_text} Confidence {int(diag['confidence'] * 100)}%.")

    # Stage 4: policy decision, then act
    time.sleep(delay)
    decision = decide(t, diag)
    article = diag["article"]

    if decision["action"] == "escalate":
        with db() as conn:
            if steps:
                add_steps(conn, ticket_id, steps)
            escalate(conn, ticket_id, decision["reason"])
        return

    if decision["action"] in ("auto_resolve", "auto_assist"):
        result = tools.run_tool(article["auto_action"], user)
        with db() as conn:
            set_fields(conn, ticket_id, auto_action=article["auto_action"])
            add_event(conn, ticket_id, "action", f"Automated action: {result['label']}. {result['message']}")
            add_steps(conn, ticket_id, [f"Automated by the agent: {result['message']}"] + steps, done_first=1)
            if decision["action"] == "auto_resolve" and result["ok"]:
                resolve(conn, ticket_id, "AI", result["message"])
                return
            set_fields(conn, ticket_id, status="Troubleshooting")
            add_event(conn, ticket_id, "troubleshooting",
                      f"Automated action completed. {len(steps)} follow-up steps are ready for the employee.")
        return

    with db() as conn:
        add_steps(conn, ticket_id, steps)
        set_fields(conn, ticket_id, status="Troubleshooting")
        add_event(conn, ticket_id, "troubleshooting",
                  f"{len(steps)} guided steps are ready (about {article['est_minutes']} minutes). Tick each step as you complete it.")
