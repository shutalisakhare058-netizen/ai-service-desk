"""Safety policy engine: decides what the agent is *allowed* to do. Pure function, easy to unit test."""
from .. import config


def decide(ticket: dict, diagnosis: dict) -> dict:
    """Returns {"action": "escalate" | "auto_resolve" | "auto_assist" | "troubleshoot", "reason": str}."""
    article = diagnosis.get("article")
    conf = diagnosis["confidence"]

    if ticket.get("security_flag"):
        return {"action": "escalate", "reason": "Possible security incident or data loss. Automated fixes are disabled and the IT Security team must review this ticket."}
    if ticket.get("severity") == "Critical":
        return {"action": "escalate", "reason": "Critical severity. Issues affecting many users or critical systems always go to a human engineer."}
    if article is None or conf < config.CONFIDENCE_ESCALATE_BELOW:
        return {"action": "escalate", "reason": f"Low confidence ({int(conf * 100)}%). No reliable knowledge base match, so the agent will not guess."}
    if article.get("risk") == "high":
        return {"action": "escalate", "reason": "Likely hardware fault that needs physical inspection or replacement. Basic checks are attached for the technician."}
    if article.get("risk") == "medium":
        return {"action": "escalate", "reason": "Identity verification may be required, so a human agent must confirm who is asking."}
    if article.get("auto_action") and conf >= config.CONFIDENCE_AUTO_ACT_AT:
        return {"action": "auto_resolve" if article.get("auto_resolves") else "auto_assist",
                "reason": "Safe, reversible automated action approved by policy."}
    return {"action": "troubleshoot", "reason": "Guided self-service steps are available."}
