"""Retrieval-Augmented Generation: knowledge base index + retrieval.

A dependency-free TF-IDF vector index with cosine similarity. It is deliberately simple so it
runs anywhere and is easy to explain in a viva. To upgrade, replace `KnowledgeBase.search`
with an embedding model + vector DB (sentence-transformers + ChromaDB/FAISS); the rest of
the system only depends on the `search()` contract.
"""
import json
import math
import re
from collections import Counter

from ..config import KB_PATH

STOPWORDS = set(
    "a an the is are was were be been to of in on for with and or but not my our your i it this that at as by "
    "from have has had can could do does did please help when after before since into out up down very just so "
    "if then than there their they them we you me am im its get got been all any some still now today again "
    "cant cannot dont wont anymore want need trying tried try".split()
)
# Normalise vocabulary so "laptop", "PC" and "computer" match, "Wi-Fi" and "wireless" match, etc.
SYNONYMS = {
    "wireless": "wifi", "wlan": "wifi", "ssid": "wifi",
    "pc": "computer", "laptop": "computer", "desktop": "computer", "machine": "computer", "notebook": "computer",
    "sluggish": "slow", "laggy": "slow", "lagging": "slow", "lag": "slow", "crawling": "slow",
    "hanging": "freeze", "hangs": "freeze", "frozen": "freeze", "froze": "freeze", "freezing": "freeze", "stuck": "stuck",
    "mail": "email", "mailbox": "email", "outlook": "email", "inbox": "email",
    "pwd": "password", "passcode": "password", "passwd": "password",
    "signin": "login", "log": "login", "logon": "login", "sign": "login",
    "crashes": "crash", "crashing": "crash", "crashed": "crash",
    "printing": "print", "printed": "print", "prints": "print",
    "internet": "network", "lan": "network", "connectivity": "network",
    "authenticator": "mfa", "2fa": "mfa",
    "webcam": "camera", "mic": "microphone", "headset": "microphone",
    "display": "monitor", "screen": "monitor",
}


def normalize(text: str) -> str:
    text = text.lower()
    for a, b in (("wi-fi", "wifi"), ("e-mail", "email"), ("log in", "login"), ("sign in", "login"),
                 ("log-in", "login"), ("can't", "cant"), ("won't", "wont"), ("doesn't", "doesnt")):
        text = text.replace(a, b)
    return text


def stem(word: str) -> str:
    for suffix in ("ing", "edly", "ed", "es", "ly", "s"):
        if word.endswith(suffix) and len(word) > len(suffix) + 3:
            return word[: -len(suffix)]
    return word


def tokenize(text: str) -> list[str]:
    tokens = re.findall(r"[a-z0-9]+", normalize(text))
    out = []
    for t in tokens:
        t = SYNONYMS.get(t, t)
        if t in STOPWORDS or len(t) < 2:
            continue
        out.append(stem(t))
    return out


class KnowledgeBase:
    def __init__(self, path=KB_PATH):
        with open(path, encoding="utf-8") as f:
            self.articles = json.load(f)
        self._build_index()

    def _doc_tokens(self, a: dict) -> list[str]:
        # Field weighting: title and tags matter most, then symptoms, then the body.
        t = tokenize(a["title"]) * 3
        t += tokenize(" ".join(a["tags"])) * 3
        t += tokenize(a["symptoms"]) * 2
        t += tokenize(a["cause"])
        t += tokenize(" ".join(a["steps"]))
        return t

    def _build_index(self):
        docs = [Counter(self._doc_tokens(a)) for a in self.articles]
        n = len(docs)
        df = Counter()
        for d in docs:
            df.update(d.keys())
        self.idf = {term: math.log((n + 1) / (cnt + 1)) + 1 for term, cnt in df.items()}
        self.vectors = [self._vectorize(d) for d in docs]

    def _vectorize(self, counts: Counter) -> dict:
        vec = {t: (1 + math.log(c)) * self.idf.get(t, 0) for t, c in counts.items() if t in self.idf}
        norm = math.sqrt(sum(v * v for v in vec.values())) or 1.0
        return {t: v / norm for t, v in vec.items()}

    def search(self, query: str, k: int = 3, category: str | None = None) -> list[dict]:
        q = self._vectorize(Counter(tokenize(query)))
        if not q:
            return []
        results = []
        for article, vec in zip(self.articles, self.vectors):
            score = sum(w * vec.get(t, 0.0) for t, w in q.items())
            if category and article["category"] == category:
                score *= 1.2  # light boost when the triage category agrees
            if score > 0:
                results.append({"score": round(score, 4), "article": article})
        results.sort(key=lambda r: r["score"], reverse=True)
        return results[:k]

    def get(self, article_id: str):
        return next((a for a in self.articles if a["id"] == article_id), None)


_kb = None


def get_kb() -> KnowledgeBase:
    global _kb
    if _kb is None:
        _kb = KnowledgeBase()
    return _kb
