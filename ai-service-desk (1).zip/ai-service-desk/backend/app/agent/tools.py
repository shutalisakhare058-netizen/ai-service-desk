"""Simulated remediation tools the agent may run on its own.

In production each function would call a real system (Active Directory, print server, MDM, mail
admin API). Here they only return a realistic result so the demo works offline. The agent can only
call tools that are named in a knowledge base article AND approved by the policy engine.
"""


def unlock_account(user: dict) -> dict:
    return {"ok": True, "message": f"Active Directory account for {user['email']} unlocked and lockout counter reset (simulated)."}


def send_password_reset(user: dict) -> dict:
    return {"ok": True, "message": f"Password reset link emailed to the recovery address on file for {user['email']} (simulated)."}


def clear_print_queue(user: dict) -> dict:
    return {"ok": True, "message": "Remote print spooler restarted on the print server and 3 stuck jobs removed (simulated)."}


def refresh_vpn_profile(user: dict) -> dict:
    return {"ok": True, "message": "Fresh VPN configuration profile pushed to the user's device through MDM (simulated)."}


def resync_mailbox(user: dict) -> dict:
    return {"ok": True, "message": "Exchange mailbox sync forced from the server side; mailbox health check passed (simulated)."}


TOOLS = {
    "unlock_account": {"fn": unlock_account, "label": "Unlock directory account"},
    "send_password_reset": {"fn": send_password_reset, "label": "Send password reset link"},
    "clear_print_queue": {"fn": clear_print_queue, "label": "Clear print queue and restart spooler"},
    "refresh_vpn_profile": {"fn": refresh_vpn_profile, "label": "Push fresh VPN profile"},
    "resync_mailbox": {"fn": resync_mailbox, "label": "Force mailbox resync"},
}


def run_tool(name: str, user: dict) -> dict:
    tool = TOOLS.get(name)
    if not tool:
        return {"ok": False, "message": f"Unknown tool '{name}'. Not executed."}
    return {**tool["fn"](user), "label": tool["label"]}
