"""Rule-based ticket triage used by the mock AI. Returns category, priority and severity."""

CATEGORY_KEYWORDS = {
    "Wi-Fi": ["wifi", "wi-fi", "wireless", "access point", "ssid", "signal"],
    "Network": ["vpn", "ethernet", "network", "internet", "lan", "dns", "proxy", "remote access", "docking"],
    "Password/Login": ["password", "login", "log in", "sign in", "locked", "lockout", "mfa", "2fa",
                       "authenticator", "credentials", "verification code", "access denied"],
    "Email": ["email", "e-mail", "outlook", "mailbox", "inbox", "calendar invite", "attachment", "smtp"],
    "Printer": ["printer", "print", "toner", "scanner", "paper jam", "spooler"],
    "System Performance": ["slow", "freezing", "freeze", "lag", "laggy", "performance", "high cpu", "memory",
                           "hangs", "takes forever", "sluggish", "fan"],
    "Hardware": ["laptop", "monitor", "keyboard", "mouse", "battery", "charger", "black screen", "power on",
                 "hdmi", "usb", "webcam", "headset", "broken", "cracked", "hardware", "docking station"],
    "Software": ["software", "install", "application", "app ", "crash", "excel", "word", "teams", "zoom",
                 "update", "license", "error message", "program"],
}

SECURITY_WORDS = ["virus", "malware", "ransomware", "phishing", "hacked", "breach", "suspicious", "stolen",
                  "compromised", "encrypted my files", "ransom", "data leak", "unauthorized"]
DATA_LOSS_WORDS = ["data loss", "lost all", "lost my files", "deleted files", "files are gone", "corrupted files",
                   "disk failure", "smoke", "burning smell"]
URGENT_WORDS = ["urgent", "asap", "immediately", "emergency", "right now", "deadline", "presentation", "client",
                "demo", "in 10 minutes", "in 30 minutes", "today", "cannot work", "can't work", "unable to work",
                "blocked", "production", "board meeting"]
WIDE_SCOPE_WORDS = ["everyone", "whole team", "entire", "all users", "all employees", "whole floor", "department",
                    "server", "outage", "multiple people", "many people", "other colleagues", "office is down"]
MINOR_WORDS = ["sometimes", "occasionally", "minor", "when i have time", "how do i", "question", "not urgent",
               "low priority", "cosmetic"]
BLOCKED_WORDS = ["cannot", "can't", "unable", "won't", "will not", "not working", "doesn't work", "does not work",
                 "completely", "stopped working", "no access"]


def _hits(text: str, words: list[str]) -> int:
    return sum(1 for w in words if w in text)


def analyze(title: str, description: str, user_category: str | None = None) -> dict:
    text = f" {title} {description} ".lower()
    scores = {cat: _hits(text, kws) for cat, kws in CATEGORY_KEYWORDS.items()}
    # Title words count double: people put the key problem there.
    for cat, kws in CATEGORY_KEYWORDS.items():
        scores[cat] += _hits(f" {title.lower()} ", kws)
    if user_category in scores:
        scores[user_category] += 0.5  # tie-breaker toward the employee's own choice
    best = max(scores, key=scores.get)
    category = best if scores[best] > 0 else (user_category or "Software")
    total = sum(scores.values()) or 1
    cat_conf = round(min(0.98, 0.5 + 0.5 * scores[best] / total), 2) if scores[best] > 0 else 0.4

    security = _hits(text, SECURITY_WORDS) > 0
    data_loss = _hits(text, DATA_LOSS_WORDS) > 0
    urgency = _hits(text, URGENT_WORDS)
    wide = _hits(text, WIDE_SCOPE_WORDS) > 0
    blocked = _hits(text, BLOCKED_WORDS) > 0
    minor = _hits(text, MINOR_WORDS) > 0

    if security or data_loss or (wide and blocked):
        severity = "Critical"
    elif wide or (blocked and urgency):
        severity = "Major"
    elif minor and not blocked:
        severity = "Minor"
    else:
        severity = "Moderate"

    if security or severity == "Critical" or urgency >= 2:
        priority = "Urgent"
    elif urgency == 1 or severity == "Major":
        priority = "High"
    elif severity == "Minor":
        priority = "Low"
    else:
        priority = "Medium"

    reasons = []
    if security:
        reasons.append("security-related wording detected")
    if data_loss:
        reasons.append("possible data loss or physical hazard")
    if wide:
        reasons.append("multiple users or a shared system may be affected")
    if urgency:
        reasons.append("time pressure mentioned")
    if not reasons:
        reasons.append("single-user impact with no urgency signals")

    return {
        "category": category,
        "category_confidence": cat_conf,
        "priority": priority,
        "severity": severity,
        "security_flag": security or data_loss,
        "reason": "Assessment: " + "; ".join(reasons) + ".",
    }
