"""LLM abstraction. `MockLLM` runs offline; `AnthropicLLM` is used automatically when an API key exists.

Design rule: the LLM may *word* the diagnosis and steps, but it never chooses which automated
tool runs. Tools come only from the knowledge base article and are gated by policy.py.
"""
import json

from .. import config
from . import triage as triage_rules


class MockLLM:
    name = "mock-rules-engine"

    def triage(self, title: str, description: str, user_category: str | None) -> dict:
        return triage_rules.analyze(title, description, user_category)

    def diagnose(self, ticket: dict, hits: list[dict]) -> dict:
        if not hits:
            return {
                "diagnosis": "No knowledge base article matched this issue closely enough to diagnose it safely.",
                "steps": [], "confidence": 0.1, "article": None,
            }
        top = hits[0]
        article = top["article"]
        # Map retrieval similarity to a 0-1 confidence. A clear lead over the runner-up adds confidence.
        confidence = 0.10 + 0.85 * top["score"]
        if len(hits) > 1:
            confidence += min(0.08, (top["score"] - hits[1]["score"]) * 0.5)
        if ticket.get("category") == article["category"]:
            confidence += 0.06
        confidence = round(max(0.05, min(0.96, confidence)), 2)

        diagnosis = (
            f"Most likely cause: {article['cause']} "
            f"The symptoms match knowledge base article {article['id']} ({article['title']})."
        )
        if len(hits) > 1 and hits[1]["score"] > 0.6 * top["score"]:
            diagnosis += f" A secondary possibility is {hits[1]['article']['title'].lower()} ({hits[1]['article']['id']})."
        return {"diagnosis": diagnosis, "steps": list(article["steps"]), "confidence": confidence, "article": article}


class AnthropicLLM(MockLLM):
    """Uses a real model to write friendlier wording. Falls back to the mock on any error."""

    def __init__(self):
        import anthropic  # imported lazily so the mock needs no extra package
        self.client = anthropic.Anthropic(api_key=config.ANTHROPIC_API_KEY)
        self.name = f"anthropic:{config.ANTHROPIC_MODEL}"

    def _ask_json(self, system: str, prompt: str) -> dict:
        msg = self.client.messages.create(
            model=config.ANTHROPIC_MODEL, max_tokens=1200, system=system,
            messages=[{"role": "user", "content": prompt}],
        )
        text = "".join(b.text for b in msg.content if getattr(b, "type", "") == "text").strip()
        text = text.removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        return json.loads(text)

    def triage(self, title, description, user_category):
        base = super().triage(title, description, user_category)
        try:
            data = self._ask_json(
                "You are an IT service desk triage engine. Reply with JSON only.",
                f"Ticket title: {title}\nDescription: {description}\n"
                'Return {"category": one of [Network, Wi-Fi, Software, Hardware, Email, Password/Login, Printer, System Performance], '
                '"priority": one of [Low, Medium, High, Urgent], "severity": one of [Minor, Moderate, Major, Critical], '
                '"security_flag": boolean, "reason": one short sentence}',
            )
            if data.get("category") in triage_rules.CATEGORY_KEYWORDS and data.get("priority") in ("Low", "Medium", "High", "Urgent") \
                    and data.get("severity") in ("Minor", "Moderate", "Major", "Critical"):
                # Never let the model downgrade a rule-detected security issue.
                data["security_flag"] = bool(data.get("security_flag")) or base["security_flag"]
                data.setdefault("reason", base["reason"])
                data["category_confidence"] = base["category_confidence"]
                return data
        except Exception:
            pass
        return base

    def diagnose(self, ticket, hits):
        base = super().diagnose(ticket, hits)
        if not base["article"]:
            return base
        try:
            context = "\n\n".join(
                f"[{h['article']['id']}] {h['article']['title']}\nCause: {h['article']['cause']}\n"
                + "\n".join(f"- {s}" for s in h["article"]["steps"]) for h in hits
            )
            data = self._ask_json(
                "You are an IT support agent. Use ONLY the knowledge base context. Reply with JSON only.",
                f"Employee issue: {ticket['title']}\n{ticket['description']}\n\nKnowledge base:\n{context}\n\n"
                'Return {"diagnosis": "2 sentences, plain language", "steps": ["3-6 short imperative steps from the context"]}',
            )
            if isinstance(data.get("steps"), list) and data["steps"] and data.get("diagnosis"):
                base["diagnosis"] = data["diagnosis"]
                base["steps"] = [str(s) for s in data["steps"]][:8]
        except Exception:
            pass
        return base


_llm = None


def get_llm() -> MockLLM:
    global _llm
    if _llm is None:
        if config.ANTHROPIC_API_KEY:
            try:
                _llm = AnthropicLLM()
            except Exception:
                _llm = MockLLM()
        else:
            _llm = MockLLM()
    return _llm
