"""Central configuration. Everything can be overridden with environment variables."""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = Path(os.getenv("DESK_DB", BASE_DIR / "data" / "servicedesk.db"))
KB_PATH = BASE_DIR / "kb" / "articles.json"
FRONTEND_DIR = BASE_DIR.parent / "frontend"

# If ANTHROPIC_API_KEY is set the agent uses a real LLM for wording the diagnosis;
# otherwise the deterministic mock engine is used (no paid API needed).
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")
ANTHROPIC_MODEL = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-5-5")

# Seconds between agent stages. Gives the demo a visible "AI is working" progression.
STEP_DELAY = float(os.getenv("AGENT_STEP_DELAY", "1.2"))

# Agent guardrails
CONFIDENCE_ESCALATE_BELOW = 0.45   # below this the agent does not guess, it escalates
CONFIDENCE_AUTO_ACT_AT = 0.60      # minimum confidence before running a safe automated action
