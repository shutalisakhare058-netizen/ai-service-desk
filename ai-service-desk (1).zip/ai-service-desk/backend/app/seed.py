"""Demo data: users plus ~45 historical tickets processed by the real agent pipeline.

Tickets are run through the actual agent (with no delay), then their timestamps and outcomes are
back-dated so the analytics dashboard has a realistic month of history.
"""
import random
from datetime import datetime, timedelta, timezone

from .agent import orchestrator as agent
from .auth import hash_password
from .database import db, now_iso

USERS = [
    ("Ananya Sharma", "employee@demo.com", "demo123", "employee", "Finance"),
    ("Rohan Mehta", "rohan@demo.com", "demo123", "employee", "Sales"),
    ("Sara Khan", "sara@demo.com", "demo123", "employee", "Marketing"),
    ("Vikram Rao", "vikram@demo.com", "demo123", "employee", "HR"),
    ("Priya Nair", "admin@demo.com", "admin123", "admin", "IT Support"),
    ("Marcus Lee", "marcus@demo.com", "admin123", "admin", "IT Support"),
]

# (title, description, category the employee picked)
TEMPLATES = [
    ("Wi-Fi connected but no internet", "My laptop says it is connected to the office wifi but no websites or Teams load since this morning.", "Wi-Fi"),
    ("Wi-Fi keeps dropping in meeting room B", "The wireless signal disconnects every few minutes and my video calls freeze. It is slow all day.", "Wi-Fi"),
    ("VPN will not connect from home", "Working from home and the VPN client shows connection timeout every time I try.", "Network"),
    ("No network on my desk ethernet", "The network cable unplugged message appears on my docking station and I have no internet.", "Network"),
    ("Forgot my password", "I forgot my password after the long weekend and the login screen rejects everything I type.", "Password/Login"),
    ("Account locked out", "I typed my password wrong too many times and now my account is locked. I cannot log in.", "Password/Login"),
    ("Authenticator codes rejected", "My new phone does not have the authenticator app set up and I cannot sign in with MFA.", "Password/Login"),
    ("Outlook not receiving emails", "Outlook has been stuck on updating and I have not received any new email since morning.", "Email"),
    ("Mailbox is full", "Outlook says my mailbox is full and I cannot send emails with attachments.", "Email"),
    ("Printer on 3rd floor is offline", "The shared printer shows offline and nothing prints from my computer.", "Printer"),
    ("Print job stuck in queue", "My document is stuck in the print queue with status deleting and nothing else will print.", "Printer"),
    ("Computer is very slow", "My computer freezes all the time and takes ages to start up, the fan is very loud.", "System Performance"),
    ("Excel keeps crashing", "Excel closes by itself whenever I open the monthly budget file. Error appears on start.", "Software"),
    ("Teams camera not working", "Colleagues cannot see me in meetings, Teams says no camera detected. Headset microphone also silent.", "Software"),
    ("Laptop will not turn on", "My laptop shows a black screen and no power even after plugging in the charger.", "Hardware"),
    ("Second monitor shows no signal", "My external monitor over HDMI says no signal after I came back from lunch.", "Hardware"),
    ("Clicked a suspicious link", "I clicked a link in a phishing email and now a strange window appears. I think my account is compromised.", "Email"),
    ("Everyone on 4th floor has no wifi", "The whole floor cannot connect to wifi, looks like an outage. Client demo in an hour, urgent!", "Wi-Fi"),
    ("Need a standing desk ordered", "Please arrange a standing desk and a footrest for my workstation.", "Hardware"),
    ("Badge reader not opening door", "My access badge does not open the 2nd floor server room door anymore.", "Hardware"),
]


def _iso(dt: datetime) -> str:
    return dt.replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _parse(ts: str) -> datetime:
    return datetime.fromisoformat(ts.replace("Z", "+00:00"))


def seed_if_empty(count: int = 45) -> None:
    with db() as conn:
        if conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]:
            return
        for name, email, pw, role, dept in USERS:
            conn.execute("INSERT INTO users(name, email, password_hash, role, department, created_at) VALUES (?,?,?,?,?,?)",
                         (name, email, hash_password(pw), role, dept, now_iso()))
        employees = [r["id"] for r in conn.execute("SELECT id FROM users WHERE role = 'employee' ORDER BY id")]

    rng = random.Random(7)
    now = datetime.now(timezone.utc)
    for i in range(count):
        title, desc, cat = rng.choice(TEMPLATES)
        uid = rng.choices(employees, weights=[4, 2, 2, 2])[0]
        with db() as conn:
            ts = now_iso()
            cur = conn.execute("INSERT INTO tickets(user_id, title, description, user_category, status, created_at, updated_at) VALUES (?,?,?,?,?,?,?)",
                               (uid, title, desc, cat, "Open", ts, ts))
            tid = cur.lastrowid
            conn.execute("UPDATE tickets SET ticket_no = ? WHERE id = ?", (f"TCK-{1000 + tid}", tid))
            agent.add_event(conn, tid, "created", "Ticket created.", "employee")
        agent.run_pipeline(tid, delay=0)
        _backdate(tid, now, rng, recent=i >= count - 9)  # the newest few stay open so dashboards show live work


def _backdate(tid: int, now: datetime, rng: random.Random, recent: bool = False) -> None:
    age_hours = rng.uniform(0.3, 20) if recent else 24 * 29 * rng.random() ** 1.3 + 2
    new_created = now - timedelta(hours=age_hours)
    with db() as conn:
        t = dict(conn.execute("SELECT * FROM tickets WHERE id = ?", (tid,)).fetchone())
        delta = new_created - _parse(t["created_at"])
        for e in conn.execute("SELECT id, created_at FROM events WHERE ticket_id = ?", (tid,)).fetchall():
            conn.execute("UPDATE events SET created_at = ? WHERE id = ?", (_iso(_parse(e["created_at"]) + delta), e["id"]))
        resolved_at = None
        if t["status"] == "Resolved":
            resolved_at = new_created + timedelta(minutes=rng.randint(1, 3))
        elif t["status"] == "Troubleshooting" and not recent and (age_hours > 48 or rng.random() < 0.7):
            conn.execute("UPDATE steps SET done = 1 WHERE ticket_id = ?", (tid,))
            agent.resolve(conn, tid, "Employee")
            resolved_at = new_created + timedelta(minutes=rng.randint(12, 120))
        elif t["status"] == "Escalated" and not recent and age_hours > 36 and rng.random() < 0.85:
            agent.add_event(conn, tid, "note", "Investigated remotely and on site; fix applied and verified with the employee.", "it")
            agent.resolve(conn, tid, "IT", "Engineer applied a fix after investigation and verified it with the employee.", actor="it")
            resolved_at = new_created + timedelta(hours=rng.uniform(2, 30))
            if resolved_at > now:
                resolved_at = now - timedelta(minutes=5)
        fields = {"created_at": _iso(new_created), "updated_at": _iso(resolved_at or new_created + timedelta(minutes=3))}
        if t["escalated_at"] or agent_escalated(conn, tid):
            fields["escalated_at"] = _iso(new_created + timedelta(minutes=2))
        if resolved_at:
            fields["resolved_at"] = _iso(resolved_at)
            res_event = conn.execute("SELECT id FROM events WHERE ticket_id = ? AND stage = 'resolution' ORDER BY id DESC LIMIT 1", (tid,)).fetchone()
            if res_event:
                conn.execute("UPDATE events SET created_at = ? WHERE id = ?", (_iso(resolved_at), res_event["id"]))
        cols = ", ".join(f"{k} = ?" for k in fields)
        conn.execute(f"UPDATE tickets SET {cols} WHERE id = ?", (*fields.values(), tid))


def agent_escalated(conn, tid) -> bool:
    return conn.execute("SELECT 1 FROM events WHERE ticket_id = ? AND stage = 'escalation'", (tid,)).fetchone() is not None
