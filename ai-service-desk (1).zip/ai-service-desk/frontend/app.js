/* AI IT Service Desk: single-page frontend (vanilla JS, no build step). */
const state = { user: null, token: localStorage.getItem("desk_token"), meta: null, poll: null };
const $ = (s, el = document) => el.querySelector(s);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const slug = (s) => String(s || "").toLowerCase().replace(/[^a-z]+/g, "-");

async function api(path, opts = {}) {
  const res = await fetch("/api" + path, {
    method: opts.method || "GET",
    headers: { "Content-Type": "application/json", ...(state.token ? { Authorization: "Bearer " + state.token } : {}) },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && path !== "/auth/login") { signOut(); throw new Error("Your session expired. Please sign in again."); }
  if (!res.ok) throw new Error(Array.isArray(data.detail) ? "Please check the form fields and try again." : data.detail || "Something went wrong.");
  return data;
}
function toast(msg) { const t = $("#toast"); t.textContent = msg; t.classList.add("show"); setTimeout(() => t.classList.remove("show"), 2600); }
function ago(ts) { const s = (Date.now() - new Date(ts)) / 1000; if (s < 60) return "just now"; if (s < 3600) return Math.floor(s / 60) + " min ago"; if (s < 86400) return Math.floor(s / 3600) + " h ago"; return Math.floor(s / 86400) + " d ago"; }
const fmt = (ts) => new Date(ts).toLocaleString([], { dateStyle: "medium", timeStyle: "short" });
const debounce = (fn, ms = 250) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

/* ---------- small components ---------- */
const statusBadge = (s) => `<span class="badge s-${slug(s)}">${esc(s)}</span>`;
const prioTag = (p) => (p ? `<span class="tag p-${slug(p)}">${esc(p)}</span>` : `<span class="muted small">Pending</span>`);
const sevTag = (v) => (v ? `<span class="tag v-${slug(v)}">${esc(v)}</span>` : `<span class="muted small">Pending</span>`);
const isAdmin = () => state.user.role === "admin";

function ticketTable(rows, showRequester) {
  if (!rows.length) return `<div class="empty"><strong>No tickets match</strong>Try clearing a filter or searching with different words.</div>`;
  return `<div class="table-wrap"><table><thead><tr><th>Ticket</th>${showRequester ? "<th>Requester</th>" : ""}<th>Category</th><th>Priority</th><th>Severity</th><th>Status</th>${showRequester ? "<th>Assignee</th>" : ""}<th>Created</th></tr></thead><tbody>${rows.map((t) => `
    <tr data-id="${t.id}"><td class="title"><a href="#/ticket/${t.id}">${esc(t.title)}</a><div class="ticket-no">${esc(t.ticket_no)}</div></td>
    ${showRequester ? `<td>${esc(t.requester)}<div class="ticket-no">${esc(t.department)}</div></td>` : ""}
    <td>${esc(t.category)}</td><td>${prioTag(t.priority)}</td><td>${sevTag(t.severity)}</td><td>${statusBadge(t.status)}</td>
    ${showRequester ? `<td>${t.assignee ? esc(t.assignee) : '<span class="muted">Unassigned</span>'}</td>` : ""}
    <td class="muted small" title="${fmt(t.created_at)}">${ago(t.created_at)}</td></tr>`).join("")}</tbody></table></div>`;
}
function bindRows(root) { root.querySelectorAll("tbody tr").forEach((tr) => tr.addEventListener("click", (e) => { if (e.target.tagName !== "A") location.hash = "#/ticket/" + tr.dataset.id; })); }

function filterBar() {
  const opt = (arr, label) => `<option value="">${label}</option>` + arr.map((x) => `<option>${esc(x)}</option>`).join("");
  return `<div class="filters">
    <input class="search" id="f-q" type="search" placeholder="Search title, description, ticket number${isAdmin() ? ", requester" : ""}" aria-label="Search tickets">
    <select id="f-status" aria-label="Status">${opt(state.meta.statuses, "All statuses")}</select>
    <select id="f-category" aria-label="Category">${opt(state.meta.categories, "All categories")}</select>
    <select id="f-priority" aria-label="Priority">${opt(state.meta.priorities, "All priorities")}</select>
    <select id="f-sort" aria-label="Sort"><option value="newest">Newest first</option><option value="oldest">Oldest first</option><option value="priority">Highest priority</option></select></div>`;
}
function wireFilters(load) {
  const run = debounce(load, 200);
  ["q", "status", "category", "priority", "sort"].forEach((k) => $("#f-" + k).addEventListener(k === "q" ? "input" : "change", run));
}
function filterQuery(extra = "") {
  const p = new URLSearchParams();
  for (const k of ["q", "status", "category", "priority"]) { const v = $("#f-" + k).value.trim(); if (v) p.set(k, v); }
  p.set("sort", $("#f-sort").value);
  return "?" + p.toString() + extra;
}

/* ---------- shell ---------- */
function shell(inner, active) {
  const nav = isAdmin()
    ? [["#/admin", "Overview"], ["#/tickets", "All tickets"], ["#/kb", "Knowledge base"]]
    : [["#/", "Dashboard"], ["#/new", "New ticket"], ["#/tickets", "Ticket history"], ["#/kb", "Knowledge base"]];
  $("#app").innerHTML = `<header class="topbar"><div class="topbar-inner">
      <a class="brand" href="${isAdmin() ? "#/admin" : "#/"}"><span class="brand-mark"></span>Resolve</a>
      <nav class="nav">${nav.map(([h, l]) => `<a href="${h}" class="${h === active ? "active" : ""}">${l}</a>`).join("")}</nav>
      <div class="userbox"><span><strong>${esc(state.user.name)}</strong> · ${isAdmin() ? "IT Support" : esc(state.user.department)}</span><button class="linkbtn" id="signout">Sign out</button></div>
    </div></header><main id="view">${inner}</main>`;
  $("#signout").onclick = () => signOut();
}

/* ---------- login ---------- */
function viewLogin() {
  $("#app").innerHTML = `<div class="login"><section class="login-side">
      <div class="brand"><span class="brand-mark"></span>Resolve</div>
      <h1>IT problems, diagnosed and fixed before you pick up the phone.</h1>
      <p>Describe what is wrong. An AI agent triages the ticket, searches the knowledge base, walks you through the fix, and hands the case to an engineer when it should not decide alone.</p>
      <div class="flow"><span>Ticket</span><b>›</b><span>Triage</span><b>›</b><span>Knowledge search</span><b>›</b><span>Diagnosis</span><b>›</b><span>Fix</span><b>›</b><span>Escalate if needed</span></div>
    </section>
    <section class="login-form"><div class="login-card"><h2 style="font-size:22px;margin-bottom:6px">Sign in</h2><p class="muted" style="margin-bottom:22px">Use your company email address.</p>
      <form id="login"><div class="field"><label for="email">Email</label><input id="email" type="email" autocomplete="username" required></div>
      <div class="field"><label for="pw">Password</label><input id="pw" type="password" autocomplete="current-password" required></div>
      <button class="btn primary" style="width:100%;justify-content:center;margin-top:18px">Sign in</button><div class="error" id="login-err" role="alert"></div></form>
      <div class="demo-accounts"><span class="small muted" style="width:100%">Demo accounts</span>
        <button class="chip" data-e="employee@demo.com" data-p="demo123">Employee</button><button class="chip" data-e="admin@demo.com" data-p="admin123">IT admin</button></div>
    </div></section></div>`;
  document.querySelectorAll(".chip[data-e]").forEach((b) => (b.onclick = () => { $("#email").value = b.dataset.e; $("#pw").value = b.dataset.p; }));
  $("#login").onsubmit = async (e) => {
    e.preventDefault();
    try {
      const r = await api("/auth/login", { method: "POST", body: { email: $("#email").value, password: $("#pw").value } });
      state.token = r.token; state.user = r.user; localStorage.setItem("desk_token", r.token);
      state.meta = await api("/meta"); location.hash = isAdmin() ? "#/admin" : "#/"; route();
    } catch (err) { $("#login-err").textContent = err.message; }
  };
}
function signOut() {
  if (state.token) fetch("/api/auth/logout", { method: "POST", headers: { Authorization: "Bearer " + state.token } }).catch(() => {});
  state.token = null; state.user = null; localStorage.removeItem("desk_token"); location.hash = "#/"; viewLogin();
}

/* ---------- employee dashboard ---------- */
async function viewHome() {
  if (isAdmin()) { location.hash = "#/admin"; return; }
  shell(`<div class="muted">Loading…</div>`, "#/");
  const rows = await api("/tickets?sort=newest");
  const n = (s) => rows.filter((t) => t.status === s).length;
  const attention = rows.filter((t) => t.status === "Troubleshooting");
  $("#view").innerHTML = `<div class="page-head"><div><h1>Hello, ${esc(state.user.name.split(" ")[0])}</h1><p>Here is where your IT requests stand.</p></div><a class="btn primary" href="#/new">Report an issue</a></div>
    <div class="tiles"><div class="tile"><div class="num">${n("Troubleshooting") + n("AI Investigating") + n("Open")}</div><div class="lbl">In progress</div></div>
      <div class="tile"><div class="num">${n("Escalated")}</div><div class="lbl">With IT engineers</div></div>
      <div class="tile"><div class="num">${n("Resolved")}</div><div class="lbl">Resolved</div></div>
      <div class="tile"><div class="num">${rows.length}</div><div class="lbl">Total tickets</div></div></div>
    ${attention.length ? `<div class="panel callout" style="background:var(--amber-tint);border-color:#e6cc9b;margin-bottom:16px"><h3>${attention.length} ticket${attention.length > 1 ? "s are" : " is"} waiting on you</h3>
      ${attention.map((t) => `<p><a href="#/ticket/${t.id}">${esc(t.title)}</a> <span class="muted small">has troubleshooting steps ready.</span></p>`).join("")}</div>` : ""}
    <div class="panel"><div class="panel-head"><h2>Recent tickets</h2><a href="#/tickets" class="small">View all history</a></div>${ticketTable(rows.slice(0, 6), false)}</div>`;
  bindRows($("#view"));
}

/* ---------- new ticket ---------- */
const EXAMPLES = [
  ["Wi-Fi, no internet", "Wi-Fi connected but no internet", "My laptop says it is connected to the office wifi but no websites or Teams load since this morning."],
  ["Account locked", "Account locked out", "I typed my password wrong too many times and now my account is locked. I cannot log in."],
  ["Outlook not syncing", "Outlook not receiving emails", "Outlook is stuck on updating and I have not received any new email since morning."],
  ["Slow computer", "My computer is very slow", "It freezes all the time and takes ages to start up, and the fan is very loud."],
  ["Laptop will not start", "Laptop will not turn on", "Black screen and no power at all, even after plugging in the charger."],
  ["Suspicious email", "Clicked a suspicious link", "I clicked a link in a phishing email and a strange window appeared. I think my account is compromised."],
  ["Outside the knowledge base", "Need a standing desk", "Please arrange a standing desk and footrest for my workstation."],
];
function viewNew() {
  shell(`<div class="page-head"><div><h1>Report an IT issue</h1><p>Describe the problem in your own words. The AI agent starts working as soon as you submit.</p></div></div>
    <div class="grid cols-main"><form class="panel" id="new"><div class="field"><label for="title">What is going wrong?</label><input id="title" maxlength="120" placeholder="e.g. Outlook will not open" required></div>
      <div class="field"><label for="category">Category</label><select id="category"><option value="">Let the AI decide</option>${state.meta.categories.map((c) => `<option>${esc(c)}</option>`).join("")}</select>
        <div class="hint">The agent re-checks this from your description, so a wrong guess is fine.</div></div>
      <div class="field"><label for="desc">Details</label><textarea id="desc" placeholder="What happened, when it started, any error message, and what you already tried."></textarea></div>
      <div style="margin-top:18px"><button class="btn primary" id="submit">Submit ticket</button></div><div class="error" id="err" role="alert"></div></form>
      <aside class="panel"><h3>Try an example</h3><p class="small muted" style="margin-top:4px">Fill the form with a sample issue to see how the agent responds to different cases.</p>
        <div class="examples">${EXAMPLES.map((e, i) => `<button type="button" class="chip" data-i="${i}">${esc(e[0])}</button>`).join("")}</div></aside></div>`, "#/new");
  document.querySelectorAll(".chip[data-i]").forEach((b) => (b.onclick = () => { const e = EXAMPLES[b.dataset.i]; $("#title").value = e[1]; $("#desc").value = e[2]; $("#category").value = ""; }));
  $("#new").onsubmit = async (ev) => {
    ev.preventDefault(); $("#submit").disabled = true; $("#err").textContent = "";
    try {
      const t = await api("/tickets", { method: "POST", body: { title: $("#title").value, description: $("#desc").value, category: $("#category").value || null } });
      location.hash = "#/ticket/" + t.id;
    } catch (e) { $("#err").textContent = e.message; $("#submit").disabled = false; }
  };
}

/* ---------- ticket list / history ---------- */
async function viewTickets() {
  shell(`<div class="page-head"><div><h1>${isAdmin() ? "All tickets" : "Ticket history"}</h1><p>${isAdmin() ? "Search and filter every ticket across the company." : "Every issue you have reported."}</p></div></div>
    <div class="panel">${filterBar()}<div id="list"></div></div>`, "#/tickets");
  const load = async () => { const rows = await api("/tickets" + filterQuery()); $("#list").innerHTML = ticketTable(rows, isAdmin()); bindRows($("#list")); };
  wireFilters(load); load();
}

/* ---------- ticket detail ---------- */
function pipeline(t) {
  const working = ["Open", "AI Investigating"].includes(t.status);
  const finished = ["Resolved", "Escalated"].includes(t.status);
  const hasKb = t.events.some((e) => e.stage === "kb_search");
  const flags = [true, !!t.priority, hasKb, !!t.diagnosis, finished];
  const active = working || t.status === "Troubleshooting" ? flags.findIndex((f) => !f) : -1;
  const names = ["Ticket received", "Triage", "Knowledge search", "Diagnosis", t.steps.length || !finished ? "Troubleshooting" : "Troubleshooting skipped"];
  const nodes = names.map((n, i) => {
    let cls = flags[i] ? "done" : i === active ? "active" : "pending";
    if (i === 4 && finished && !t.steps.length) cls = "skipped";
    return `<div class="stage ${cls}"><div class="dot">${cls === "done" ? "✓" : i + 1}</div>${n}</div>`;
  });
  const [fc, fl] = t.status === "Resolved" ? ["ok", "Resolved"] : t.status === "Escalated" ? ["bad", "Escalated to IT"] : ["pending", "Outcome"];
  nodes.push(`<div class="stage ${fc}"><div class="dot">${fc === "ok" ? "✓" : fc === "bad" ? "!" : 6}</div>${fl}</div>`);
  return `<div class="pipeline" role="list" aria-label="Agent progress">${nodes.join("")}</div>`;
}
const actorLabel = (a, t) => ({ ai: "AI agent", it: "IT support", employee: t.requester, system: "System" }[a] || a);

function stepsPanel(t) {
  if (!t.steps.length) return "";
  const done = t.steps.filter((s) => s.done).length, pct = Math.round((100 * done) / t.steps.length);
  const live = t.status === "Troubleshooting";
  return `<div class="panel"><div class="panel-head"><h2>Troubleshooting steps</h2><span class="small muted">${done} of ${t.steps.length} done</span></div>
    <div class="meter"><span style="width:${pct}%"></span></div><ul class="steps" style="margin-top:14px">${t.steps.map((s) => `
      <li class="step ${s.done ? "done" : ""}"><input type="checkbox" id="st${s.id}" data-id="${s.id}" ${s.done ? "checked" : ""} ${live ? "" : "disabled"}><label for="st${s.id}" style="margin:0;font-weight:400"><span>${esc(s.text)}</span></label></li>`).join("")}</ul>
    ${live ? `<div style="margin-top:18px;border-top:1px solid var(--line);padding-top:16px"><h3>Did this fix it?</h3>
      <textarea id="fb-note" style="min-height:64px;margin-top:10px" placeholder="Optional note for IT, e.g. what you saw after the steps"></textarea>
      <div style="display:flex;gap:10px;margin-top:12px;flex-wrap:wrap"><button class="btn good" id="fixed">Yes, it is fixed</button><button class="btn danger" id="notfixed">No, escalate to IT</button></div></div>` : ""}</div>`;
}

function adminPanel(t, engineers) {
  return `<div class="panel"><div class="panel-head"><h2>IT actions</h2></div>
    <div class="field"><label for="a-assign">Assignee</label><select id="a-assign"><option value="">Unassigned</option>${engineers.map((e) => `<option value="${e.id}" ${t.assignee === e.name ? "selected" : ""}>${esc(e.name)}</option>`).join("")}</select></div>
    <div class="field"><label for="a-status">Status</label><select id="a-status"><option value="">Keep current (${esc(t.status)})</option>${state.meta.statuses.filter((s) => s !== t.status).map((s) => `<option>${esc(s)}</option>`).join("")}</select></div>
    <div class="field"><label for="a-note">Note or resolution</label><textarea id="a-note" style="min-height:80px" placeholder="Visible on the ticket timeline. If you resolve the ticket, this becomes the resolution."></textarea></div>
    <button class="btn primary" id="a-apply" style="margin-top:14px">Apply changes</button></div>`;
}

async function viewTicket(id) {
  clearTimeout(state.poll);
  const t = await api("/tickets/" + id);
  const working = ["Open", "AI Investigating"].includes(t.status);
  const engineers = isAdmin() && !working ? await api("/admin/engineers") : [];
  const conf = t.confidence == null ? null : Math.round(t.confidence * 100);
  shell(`<p class="small" style="margin-bottom:12px"><a href="${isAdmin() ? "#/tickets" : "#/tickets"}">← ${isAdmin() ? "All tickets" : "Ticket history"}</a></p>
    <div class="page-head"><div><div class="ticket-no">${esc(t.ticket_no)}</div><h1>${esc(t.title)}</h1></div>
      <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">${statusBadge(t.status)}${t.security_flag ? '<span class="tag v-critical">Security review</span>' : ""}</div></div>
    <div class="panel" style="padding:8px 12px 4px">${pipeline(t)}${working ? '<p class="small muted" style="text-align:center;padding-bottom:10px">The agent is working on this now. This page updates by itself.</p>' : ""}</div>
    <div class="grid cols-main" style="margin-top:16px"><div class="stack">
      ${t.status === "Resolved" ? `<div class="callout ok"><h3>Resolved ${t.resolved_by === "AI" ? "automatically by the agent" : t.resolved_by === "IT" ? "by IT support" : "with the agent's guidance"}</h3><p class="desc small">${esc(t.resolution_summary)}</p>
        ${!isAdmin() ? '<p class="small" style="margin-top:10px">Problem came back? <button class="linkbtn" id="reopen" style="color:var(--teal);padding:0">Send it to IT</button></p>' : ""}</div>` : ""}
      ${t.status === "Escalated" ? `<div class="callout bad"><h3>Escalated to a human engineer${t.assignee ? ": " + esc(t.assignee) : ""}</h3><p class="small">${esc(t.escalation_reason)}</p></div>` : ""}
      <div class="panel"><h2 style="margin-bottom:10px">Description</h2><p class="desc">${esc(t.description)}</p></div>
      ${t.diagnosis ? `<div class="panel"><div class="panel-head"><h2>AI diagnosis</h2>${conf != null ? `<span class="small muted">Confidence ${conf}%</span>` : ""}</div><p>${esc(t.diagnosis)}</p>
        ${conf != null ? `<div class="meter ${conf < 45 ? "low" : conf < 65 ? "mid" : ""}"><span style="width:${conf}%"></span></div>` : ""}</div>` : ""}
      ${stepsPanel(t)}
      ${isAdmin() ? (working ? '<div class="panel muted small">IT actions unlock once the agent finishes its analysis.</div>' : adminPanel(t, engineers)) : ""}
    </div><aside class="stack">
      <div class="panel"><h2 style="margin-bottom:12px">Details</h2><dl class="kv">
        <dt>Requester</dt><dd>${esc(t.requester)}<div class="small muted">${esc(t.department)}</div></dd><dt>Category</dt><dd>${esc(t.category)}</dd>
        <dt>Priority</dt><dd>${prioTag(t.priority)}</dd><dt>Severity</dt><dd>${sevTag(t.severity)}</dd>
        <dt>Assignee</dt><dd>${t.assignee ? esc(t.assignee) : '<span class="muted">Unassigned</span>'}</dd><dt>Created</dt><dd>${fmt(t.created_at)}</dd>
        ${t.resolved_at ? `<dt>Resolved</dt><dd>${fmt(t.resolved_at)}</dd>` : ""}</dl></div>
      ${t.kb_sources.length ? `<div class="panel"><h2 style="margin-bottom:8px">Knowledge base matches</h2>${t.kb_sources.map((s) => `<div class="source"><span><strong>${esc(s.id)}</strong> ${esc(s.title)}</span><span class="muted">${Math.min(100, Math.round(s.score * 100))}%</span></div>`).join("")}<p class="hint">Percentages show how closely each article matches the ticket text.</p></div>` : ""}
      <div class="panel"><h2 style="margin-bottom:14px">Activity</h2><ol class="timeline">${t.events.map((e) => `<li class="${esc(e.actor)}"><span class="who">${esc(actorLabel(e.actor, t))}</span> ${esc(e.message)}<time>${fmt(e.created_at)}</time></li>`).join("")}</ol></div>
    </aside></div>`, "#/tickets");

  const refresh = (nt) => { toast("Updated"); viewTicket(id); };
  document.querySelectorAll(".step input").forEach((cb) => (cb.onchange = async () => {
    try { await api(`/tickets/${id}/steps/${cb.dataset.id}`, { method: "POST", body: { done: cb.checked } }); viewTicket(id); } catch (e) { toast(e.message); }
  }));
  const fb = async (resolved) => {
    try { await api(`/tickets/${id}/feedback`, { method: "POST", body: { resolved, note: $("#fb-note")?.value || "" } }); toast(resolved ? "Great, ticket resolved" : "Sent to IT"); viewTicket(id); } catch (e) { toast(e.message); }
  };
  $("#fixed") && ($("#fixed").onclick = () => fb(true));
  $("#notfixed") && ($("#notfixed").onclick = () => fb(false));
  $("#reopen") && ($("#reopen").onclick = () => fb(false));
  $("#a-apply") && ($("#a-apply").onclick = async () => {
    const body = { status: $("#a-status").value || null, assigned_to: $("#a-assign").value ? Number($("#a-assign").value) : null, note: $("#a-note").value || null };
    if (body.status === "Resolved") body.resolution = body.note;
    try { await api("/admin/tickets/" + id, { method: "PATCH", body }); refresh(); } catch (e) { toast(e.message); }
  });
  if (working) state.poll = setTimeout(() => { if (location.hash === "#/ticket/" + id) viewTicket(id); }, 1400);
}

/* ---------- admin overview ---------- */
const COLORS = { Open: "#8a96a1", "AI Investigating": "#2d5b9a", Troubleshooting: "#a86a0c", Resolved: "#2c7a4b", Escalated: "#b0402b" };
function barList(items) {
  const max = Math.max(1, ...items.map((i) => i.count));
  return `<div class="bars">${items.map((i) => `<div class="row"><span>${esc(i.label)}</span><div class="track"><span style="width:${(100 * i.count) / max}%"></span></div><span class="right">${i.count}</span></div>`).join("")}</div>`;
}
function lineChart(daily) {
  const W = 620, H = 190, P = { l: 28, r: 8, t: 10, b: 24 };
  const max = Math.max(4, ...daily.map((d) => Math.max(d.created, d.resolved)));
  const x = (i) => P.l + (i * (W - P.l - P.r)) / (daily.length - 1), y = (v) => H - P.b - (v * (H - P.t - P.b)) / max;
  const line = (k, c) => `<polyline fill="none" stroke="${c}" stroke-width="2.5" stroke-linejoin="round" points="${daily.map((d, i) => `${x(i)},${y(d[k])}`).join(" ")}"/>`;
  const grid = [0, 0.5, 1].map((f) => `<line x1="${P.l}" x2="${W - P.r}" y1="${y(max * f)}" y2="${y(max * f)}" stroke="#e5e8ea"/><text x="0" y="${y(max * f) + 4}">${Math.round(max * f)}</text>`).join("");
  const labels = daily.map((d, i) => (i % 3 === 0 ? `<text x="${x(i)}" y="${H - 6}" text-anchor="middle">${d.date.slice(5)}</text>` : "")).join("");
  return `<svg viewBox="0 0 ${W} ${H}" width="100%" role="img" aria-label="Tickets created and resolved per day">${grid}${line("created", "#0d6b6e")}${line("resolved", "#b0402b")}${labels}</svg>
    <div class="legend"><span><i style="background:#0d6b6e"></i>Created</span><span><i style="background:#b0402b"></i>Resolved</span></div>`;
}
async function viewAdmin() {
  if (!isAdmin()) { location.hash = "#/"; return; }
  shell(`<div class="muted">Loading…</div>`, "#/admin");
  const [a, queue] = await Promise.all([api("/admin/analytics"), api("/tickets?status=Escalated&sort=priority")]);
  const k = a.kpis, mins = (m) => (m == null ? "n/a" : m < 90 ? Math.round(m) + " min" : (m / 60).toFixed(1) + " h");
  const total = a.by_status.reduce((s, i) => s + i.count, 0) || 1;
  $("#view").innerHTML = `<div class="page-head"><div><h1>Service desk overview</h1><p>How the AI agent and the IT team are performing. AI engine: <strong>${esc(state.meta.ai_engine)}</strong></p></div></div>
    <div class="tiles"><div class="tile"><div class="num">${k.total}</div><div class="lbl">Total tickets</div><div class="sub">${k.active} still active</div></div>
      <div class="tile hot"><div class="num">${k.escalated_now}</div><div class="lbl">Waiting on engineers</div></div>
      <div class="tile"><div class="num">${k.ai_resolution_rate}%</div><div class="lbl">Resolved without IT</div><div class="sub">Agent fixes plus guided self-service</div></div>
      <div class="tile"><div class="num">${k.escalation_rate}%</div><div class="lbl">Escalation rate</div></div>
      <div class="tile"><div class="num">${mins(k.avg_minutes_ai)}</div><div class="lbl">Avg time, agent path</div><div class="sub">IT path: ${mins(k.avg_minutes_human)}</div></div>
      <div class="tile"><div class="num">${k.avg_confidence}%</div><div class="lbl">Avg AI confidence</div></div></div>
    <div class="grid cols-2"><div class="panel"><div class="panel-head"><h2>Tickets over the last 14 days</h2></div>${lineChart(a.daily)}</div>
      <div class="panel"><div class="panel-head"><h2>Status mix</h2></div><div class="stackbar">${a.by_status.map((s) => `<span style="width:${(100 * s.count) / total}%;background:${COLORS[s.label] || "#999"}" title="${esc(s.label)}: ${s.count}"></span>`).join("")}</div>
        <div class="legend">${a.by_status.map((s) => `<span><i style="background:${COLORS[s.label] || "#999"}"></i>${esc(s.label)} ${s.count}</span>`).join("")}</div>
        <h3 style="margin:22px 0 6px">By priority</h3>${barList(a.by_priority)}</div></div>
    <div class="grid cols-2" style="margin-top:16px"><div class="panel"><div class="panel-head"><h2>By category</h2></div>${barList(a.by_category)}</div>
      <div class="panel"><div class="panel-head"><h2>Most used knowledge articles</h2></div>${barList(a.top_articles.map((t) => ({ label: t.id + " " + t.title.slice(0, 22), count: t.count })))}</div></div>
    <div class="panel" style="margin-top:16px"><div class="panel-head"><h2>Escalation queue</h2><a class="small" href="#/tickets">All tickets</a></div>${queue.length ? ticketTable(queue, true) : '<div class="empty"><strong>Queue is clear</strong>No tickets are waiting on an engineer.</div>'}</div>`;
  bindRows($("#view"));
}

/* ---------- knowledge base ---------- */
async function viewKB() {
  shell(`<div class="page-head"><div><h1>Knowledge base</h1><p>The articles the agent retrieves from. Type a problem to see what the retrieval step finds.</p></div></div>
    <div class="panel" style="margin-bottom:16px"><label for="kbq">Test retrieval</label><input id="kbq" type="search" placeholder="e.g. outlook stuck on updating"><div id="kbres" style="margin-top:12px"></div></div><div id="kblist" class="stack"></div>`, "#/kb");
  const arts = await api("/kb");
  const card = (a, score) => `<details class="panel"><summary style="cursor:pointer"><strong>${esc(a.id)}</strong> ${esc(a.title)} <span class="tag" style="margin-left:6px">${esc(a.category)}</span>${score != null ? `<span class="muted small" style="float:right">${Math.min(100, Math.round(score * 100))}% match</span>` : ""}</summary>
    <p class="small muted" style="margin:10px 0">${esc(a.symptoms)}</p><p class="small"><strong>Likely cause:</strong> ${esc(a.cause)}</p>
    <ol class="small" style="padding-left:20px">${a.steps.map((s) => `<li>${esc(s)}</li>`).join("")}</ol>${a.escalate_if ? `<p class="small"><strong>Escalate when:</strong> ${esc(a.escalate_if)}</p>` : ""}</details>`;
  $("#kblist").innerHTML = arts.map((a) => card(a)).join("");
  $("#kbq").addEventListener("input", debounce(async () => {
    const q = $("#kbq").value.trim();
    if (q.length < 2) { $("#kbres").innerHTML = ""; return; }
    const r = await api("/kb/search?q=" + encodeURIComponent(q));
    $("#kbres").innerHTML = r.length ? r.map((h) => card(h.article, h.score)).join("") : '<p class="muted small">No matching articles. A real ticket like this would be escalated to a human.</p>';
  }));
}

/* ---------- router ---------- */
const routes = [[/^#\/new$/, viewNew], [/^#\/ticket\/(\d+)$/, (m) => viewTicket(m[1])], [/^#\/tickets$/, viewTickets], [/^#\/kb$/, viewKB], [/^#\/admin$/, viewAdmin], [/^#\/?$/, viewHome]];
async function route() {
  clearTimeout(state.poll);
  if (!state.user) return viewLogin();
  const hash = location.hash || "#/";
  for (const [re, fn] of routes) { const m = hash.match(re); if (m) { try { await fn(m); } catch (e) { if (state.user) toast(e.message); } return; } }
  location.hash = "#/";
}
window.addEventListener("hashchange", route);
(async function init() {
  if (state.token) {
    try { state.user = await api("/auth/me"); state.meta = await api("/meta"); } catch { state.token = null; localStorage.removeItem("desk_token"); }
  }
  route();
})();
