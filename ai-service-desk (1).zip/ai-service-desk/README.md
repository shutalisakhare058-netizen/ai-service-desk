# Resolve: AI IT Service Desk Autonomous Resolution Agent

An employee reports an IT problem. An AI agent triages it, searches a knowledge base (RAG), diagnoses it,
fixes it or guides the employee through the fix, and escalates to a human engineer when it should not decide alone.

Runs fully offline with a mock AI engine. No API keys, no paid services, no build step.

## 1. Quick start

```bash
cd backend
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```
Open http://localhost:8000. The database is created and filled with demo data on first start.
(To reset the demo data, stop the server and delete `backend/data/`.)

| Role | Email | Password |
|---|---|---|
| Employee | employee@demo.com | demo123 |
| IT admin | admin@demo.com | admin123 |

Tests (standard library only): `cd backend && python -m unittest discover -s tests -v`

Optional real LLM: `pip install anthropic`, then set `ANTHROPIC_API_KEY` before starting the server.
The agent then uses the model to word its triage and diagnosis; everything else is unchanged.

## 2. Architecture

```
 Browser (HTML/CSS/vanilla JS SPA)
      │  JSON over HTTP, Bearer token
      ▼
 FastAPI  (api.py: validation, auth, error mapping)
      │
      ├── services.py   tickets, steps, feedback, admin actions, analytics
      │
      └── agent/        the autonomous pipeline (runs as a background task)
            orchestrator ──► llm.py (triage + diagnosis; mock or Anthropic)
                         ──► knowledge_base.py (RAG retrieval)
                         ──► policy.py (what the agent is allowed to do)
                         ──► tools.py (simulated safe fixes)
      │
      ▼
 SQLite (users, sessions, tickets, steps, events)
```

### Agent workflow

```
Ticket created (status Open)
  → AI Investigating
  → Triage: category, priority, severity, security flag
  → RAG: top 3 knowledge base articles
  → Diagnosis: likely cause, steps, confidence score
  → Policy engine decides one of:
       escalate      → Escalated (assigned to least-loaded engineer, handoff summary attached)
       auto_resolve  → run safe tool → Resolved
       auto_assist   → run safe tool → Troubleshooting with follow-up steps
       troubleshoot  → Troubleshooting (employee ticks steps)
  → Employee confirms "fixed" → Resolved,  "not fixed" → Escalated
```

### How the parts communicate
1. The UI posts a ticket to `POST /api/tickets`. The API stores it, returns immediately, and schedules `run_pipeline` as a background task.
2. The pipeline commits after every stage (status change plus a timeline event). The UI polls `GET /api/tickets/{id}` every 1.4 s while the ticket is Open or AI Investigating, so the employee watches the agent work.
3. Retrieval: the pipeline calls `KnowledgeBase.search(text, category)`. Articles are indexed once at startup.
4. The LLM layer receives the ticket text and retrieved articles and returns structured data. It never executes anything.
5. `policy.decide()` is a pure function that approves or blocks automation. Only tools named in a knowledge base article can run.

### Safety guardrails (good viva material)
- Security wording (phishing, malware, hacked…) disables automation and escalates, with containment advice for the employee.
- Critical severity (outages, many users, data loss) always goes to a human.
- Confidence below 45% means the agent does not guess; it escalates.
- Hardware faults and identity-sensitive issues (MFA on a new phone) escalate.
- Automated actions need 60%+ confidence, are reversible, and are logged on the timeline.
- Any pipeline error escalates the ticket instead of leaving it stuck.
- The LLM can reword steps but cannot choose tools or override a rule-detected security flag.

## 3. Technology choices

| Layer | Choice | Why |
|---|---|---|
| Frontend | Vanilla JS SPA, plain CSS | No build tools; opens instantly in a demo |
| Backend | FastAPI (Python) | Typed, fast, automatic docs at `/docs` |
| Database | SQLite | Zero setup, one file |
| RAG | Own TF-IDF + cosine index | No downloads or keys; fully explainable |
| AI | Rule-based mock, optional Anthropic API | Offline by default, real LLM when available |

Upgrading RAG later: swap the body of `KnowledgeBase.search` for sentence-transformers embeddings plus ChromaDB or FAISS. Nothing else changes.

## 4. Folder structure

```
ai-service-desk/
├── README.md
├── backend/
│   ├── requirements.txt
│   ├── kb/articles.json            16 knowledge base articles
│   ├── tests/test_agent.py
│   └── app/
│       ├── main.py                 app startup, serves the frontend
│       ├── api.py                  REST endpoints
│       ├── services.py             business logic and analytics
│       ├── auth.py                 password hashing, sessions
│       ├── database.py             schema and connections
│       ├── seed.py                 demo users and ~45 back-dated tickets
│       ├── config.py               settings and thresholds
│       └── agent/
│           ├── orchestrator.py     the pipeline
│           ├── llm.py              MockLLM and AnthropicLLM
│           ├── triage.py           category, priority, severity rules
│           ├── knowledge_base.py   RAG index and search
│           ├── policy.py           guardrails
│           └── tools.py            simulated remediation actions
└── frontend/  index.html, styles.css, app.js
```

## 5. API summary

| Method | Path | Purpose |
|---|---|---|
| POST | /api/auth/login | Sign in, returns token |
| GET | /api/meta | Categories, statuses, AI engine name |
| POST | /api/tickets | Create ticket, starts the agent |
| GET | /api/tickets | List with `q`, `status`, `category`, `priority`, `sort` filters |
| GET | /api/tickets/{id} | Ticket, steps, KB matches, timeline |
| POST | /api/tickets/{id}/steps/{step} | Tick or untick a step |
| POST | /api/tickets/{id}/feedback | Employee confirms fixed or not fixed |
| PATCH | /api/admin/tickets/{id} | Assign, change status, add note, resolve |
| GET | /api/admin/analytics | KPIs and chart data |
| GET | /api/kb, /api/kb/search?q= | Browse and test retrieval |

## 6. Demo script (about 5 minutes)

1. Sign in as the employee. Show the dashboard.
2. New ticket, click **Wi-Fi, no internet**, submit. Watch the pipeline advance, then follow the steps and click "Yes, it is fixed".
3. Submit **Account locked**. The agent fixes it on its own and shows the resolution summary.
4. Submit **Suspicious email**. It escalates immediately with containment advice. Submit **Outside the knowledge base** to show the low-confidence escalation.
5. Open a Troubleshooting ticket, click "No, escalate to IT" to show the handoff.
6. Sign out, sign in as IT admin. Show the overview analytics, escalation queue, filters, and resolve an escalated ticket with a note.
7. Open Knowledge base and type a problem to show what RAG retrieves.

## 7. Known limits and next steps
- Remediation tools are simulated; real ones would call Active Directory, the print server, or an MDM.
- Sessions never expire and passwords are demo-only. Add expiry, rate limiting and HTTPS for real use.
- Polling could become WebSockets; SQLite could become PostgreSQL; TF-IDF could become embeddings.
